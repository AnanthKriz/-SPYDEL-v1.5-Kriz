# 🕷️ SPYDEL v1.5 — Kriz SpydelTrap

> 🔐 PRIVATE BUILD – NOT FOR PUBLIC DISTRIBUTION  
> 🛠️ Premium Surveillance + Phishing Framework  
> 👑 Developed & Owned by AnanthKriz

## 🚫 Public Access Denied
This is a **private, licensed tool** provided only to verified clients.
All modules are encrypted, token-gated, and monitored.

Free use or redistribution is strictly prohibited.

## 💣 What's Inside (Full Version Only)
- 🎥 Full stealth webcam capture (no popup or permissions)
- 🕸️ Auto-generated phishing page via Ngrok
- 📬 Instant image drops to your **Telegram bot**
- 🔁 Continuous background surveillance mode
- 🔐 Token-protected launcher (`KRIZ-SHADOW-007`)
- 🧾 Auto IP + device logging
- 🧠 Fully integrated Telegram API

## 💌 Purchase Access
To get this tool with full functionality, contact:

📧 **Official Mail:** `ananthkriz.official@gmail.com`

## 💰 Payment Options
📸 After payment, you will receive:
- 🔑 Personal token
- 📦 ZIP download link
- 📖 Execution guide
- 🔐 License key activation

> ✅ Once paid, you get lifetime access with all future updates.

### 📲 Scan to Pay (UPI/QR)
⬇️ Upload your QR code image as `payment_qr.png`

📍 UPI: ananthkriz@upi  
📞 PhonePay / GPay supported

## ⚠️ Legal Notice
This tool is intended for **educational, research, and authorized penetration testing only**.

You **may not:**
- Resell or re-upload this code
- Share your private token
- Use it on unauthorized targets

Misuse will result in permanent blacklist.

## 👑 Developer Info
**Author:** AnanthKriz  
**Telegram Bot:** [@SpydelSpyBot](https://t.me/SpydelSpyBot)  
**GitHub:** [github.com/AnanthKriz](https://github.com/AnanthKriz)

> "Real power moves in silence — and leaves no trace."

© 2025 Kriz Labs. All Rights Reserved.
